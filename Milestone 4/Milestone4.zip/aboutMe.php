<?php
// Include config file
require_once "config.php";
// Initialize the session
session_start();    

if(!isset($_SESSION["loggedin"]) || $_SESSION["loggedin"] !== true){
    header("location: login.php");
    exit;
}

$fname = $lname = $bday = $location = $education = $occupation = "";
$fname_err = $lname_err = $bday_err = $location_err = $education_err = $occupation_err = "";

if($_SERVER["REQUEST_METHOD"] == "POST"){
    if(empty(trim($_POST["fname"]))){
        $fname_err = "Please enter a First Name";
    } elseif(!preg_match('/^[a-zA-Z]+$/', trim($_POST["fname"]))){
        $fname_err = "First Name can only contain letters.";
    } else{
        // Prepare a select statement
        $sql = "SELECT UserID FROM Users WHERE fname = ?";
        
        if($stmt = mysqli_prepare($link, $sql)){
            // Bind variables to the prepared statement as parameters
            mysqli_stmt_bind_param($stmt, "s", $param_fname);
            
            // Set parameters
            $param_fname = trim($_POST["fname"]);
            
            // Attempt to execute the prepared statement
            if(mysqli_stmt_execute($stmt)){
                /* store result */
                mysqli_stmt_store_result($stmt); 
                $fname = trim($_POST["fname"]);
                
            } else{
                echo "Oops! Something went wrong with First Name. Please try again later.";
            }

            // Close statement
            mysqli_stmt_close($stmt);
        }
    }
    if(empty(trim($_POST["lname"]))){
        $lname_err = "Please enter a Last Name";
    } elseif(!preg_match('/^[a-zA-Z]+$/', trim($_POST["lname"]))){
        $lname_err = "Last Name can only contain letters.";
    } else{
        // Prepare a select statement
        $sql = "SELECT UserID FROM Users WHERE lname = ?";
        
        if($stmt = mysqli_prepare($link, $sql)){
            // Bind variables to the prepared statement as parameters
            mysqli_stmt_bind_param($stmt, "s", $param_lname);
            
            // Set parameters
            $param_lname = trim($_POST["lname"]);
            
            // Attempt to execute the prepared statement
            if(mysqli_stmt_execute($stmt)){
                /* store result */
                mysqli_stmt_store_result($stmt); 
                $lname = trim($_POST["lname"]);
                
            } else{
                echo "Oops! Something went wrong with Last Name. Please try again later.";
            }

            // Close statement
            mysqli_stmt_close($stmt);
        }
    }
    
//    if(empty(trim($_POST["bday"]))){
//        $bday_err = "Please enter a Birthday";
//    } elseif(!preg_match('/^[a-zA-Z]+$/', trim($_POST["bday"]))){
//        $bday_err = "Birthday must be a date.";
//    } else{
//        // Prepare a select statement
//        $sql = "SELECT UserID FROM Users WHERE bday = ?";
//        
//        if($stmt = mysqli_prepare($link, $sql)){
//            // Bind variables to the prepared statement as parameters
//            mysqli_stmt_bind_param($stmt, "s", $param_bday);
//            
//            // Set parameters
//            $param_bday = trim($_POST["bday"]);
//            
//            // Attempt to execute the prepared statement
//            if(mysqli_stmt_execute($stmt)){
//                /* store result */
//                mysqli_stmt_store_result($stmt); 
//                $fname = trim($_POST["bday"]);
//                
//            } else{
//                echo "Oops! Something went wrong with Birthday. Please try again later.";
//            }
//
//            // Close statement
//            mysqli_stmt_close($stmt);
//        }
//    }
    
    
   if(!preg_match('/^[a-zA-Z]+$/', trim($_POST["location"]))){
        $location_err = "Location can only contain letters.";
    } else{
        // Prepare a select statement
        $sql = "SELECT UserID FROM Users WHERE location = ?";
        
        if($stmt = mysqli_prepare($link, $sql)){
            // Bind variables to the prepared statement as parameters
            mysqli_stmt_bind_param($stmt, "s", $param_location);
            
            // Set parameters
            $param_location = trim($_POST["location"]);
            
            // Attempt to execute the prepared statement
            if(mysqli_stmt_execute($stmt)){
                /* store result */
                mysqli_stmt_store_result($stmt); 
                $location = trim($_POST["location"]);
                
            } else{
                echo "Oops! Something went wrong with Location. Please try again later.";
            }

            // Close statement
            mysqli_stmt_close($stmt);
        }
    }
    
     if(!preg_match('/^[a-zA-Z]+$/', trim($_POST["education"]))){
        $education_err = "Location can only contain letters.";
    } else{
        // Prepare a select statement
        $sql = "SELECT UserID FROM Users WHERE education = ?";
        
        if($stmt = mysqli_prepare($link, $sql)){
            // Bind variables to the prepared statement as parameters
            mysqli_stmt_bind_param($stmt, "s", $param_education);
            
            // Set parameters
            $param_education = trim($_POST["education"]);
            
            // Attempt to execute the prepared statement
            if(mysqli_stmt_execute($stmt)){
                /* store result */
                mysqli_stmt_store_result($stmt); 
                $education = trim($_POST["education"]);
                
            } else{
                echo "Oops! Something went wrong with Education. Please try again later.";
            }

            // Close statement
            mysqli_stmt_close($stmt);
        }
    }
    
    if(!preg_match('/^[a-zA-Z]+$/', trim($_POST["occupation"]))){
        $occupation_err = "Occupation can only contain letters.";
    } else{
        // Prepare a select statement
        $sql = "SELECT UserID FROM Users WHERE occupation = ?";
        
        if($stmt = mysqli_prepare($link, $sql)){
            // Bind variables to the prepared statement as parameters
            mysqli_stmt_bind_param($stmt, "s", $param_occupation);
            
            // Set parameters
            $param_occupation = trim($_POST["occupation"]);
            
            // Attempt to execute the prepared statement
            if(mysqli_stmt_execute($stmt)){
                /* store result */
                mysqli_stmt_store_result($stmt); 
                $occupation = trim($_POST["occupation"]);
                
            } else{
                echo "Oops! Something went wrong with occupation. Please try again later.";
            }

            // Close statement
            mysqli_stmt_close($stmt);
        }
    }
    
 // Check input errors before inserting in database
    if(empty($fname_err) && empty($lname_err)){
        
        // Prepare an insert statement
        $sql = "UPDATE Users SET fname = ?, lname = ?, location = ?, education = ?, occupation = ? WHERE UserID = ?";
         
        if($stmt = mysqli_prepare($link, $sql)){
            // Bind variables to the prepared statement as parameters
            mysqli_stmt_bind_param($stmt, "sssssi", $param_fname, $param_lname, $param_location, $param_education, $param_occupation, $param_id);
            
            // Set parameters
            $param_fname = $fname;
            $param_lname = $lname;
            $param_location = $location;
            $param_education = $education;
            $param_occupation = $occupation;
            $param_UserID = $_SESSION["UserID"];
            
            // Attempt to execute the prepared statement
            if(mysqli_stmt_execute($stmt)){
                // Redirect to login page
                header("location: welcome.php");
            } else{
                echo "Oops! Something went wrong with database. Please try again later.";
            }

            // Close statement
            mysqli_stmt_close($stmt);
        }
    }
    mysqli_close($link);
}
?>


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>About Me</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <style>
        body{ font: 14px sans-serif; }
        .wrapper{ width: 360px; padding: 20px; }
    </style>
</head>
<body>
    <strong> Test <?php echo htmlspecialchars($_SESSION["username"]); ?> </strong>
    
    <form action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>" method="post">
        <div class="form-group">
            <label>First Name</label>
            <input type="text" name="fname" class="form-control <?php echo (!empty($fname_err)) ? 'is-invalid' : ''; ?>" value="<?php echo $fname; ?>">
            <span class="invalid-feedback"><?php echo $fname_err; ?></span>
            
            <label>Last Name</label>
            <input type="text" name="lname" class="form-control <?php echo (!empty($lname_err)) ? 'is-invalid' : ''; ?>" value="<?php echo $lname; ?>">
            <span class="invalid-feedback"><?php echo $lname_err; ?></span>
            
            <label>Birthday</label>
            <input type="text" name="bday" class="form-control <?php echo (!empty($bday_err)) ? 'is-invalid' : ''; ?>" value="<?php echo $bday; ?>">
            <span class="invalid-feedback"><?php echo $bday_err; ?></span>
            
            <label>Location</label>
            <input type="text" name="location" class="form-control <?php echo (!empty($location_err)) ? 'is-invalid' : ''; ?>" value="<?php echo $location; ?>">
            <span class="invalid-feedback"><?php echo $location_err; ?></span>
            
            <label>Education</label>
            <input type="text" name="education" class="form-control <?php echo (!empty($education_err)) ? 'is-invalid' : ''; ?>" value="<?php echo $education; ?>">
            <span class="invalid-feedback"><?php echo $education_err; ?></span>
            
            <label>Occupation</label>
            <input type="text" name="occupation" class="form-control <?php echo (!empty($occupation_err)) ? 'is-invalid' : ''; ?>" value="<?php echo $occupation; ?>">
            <span class="invalid-feedback"><?php echo $occupation_err; ?></span>
            
            <div class="form-group">
                    <input type="submit" class="btn btn-primary" value="Submit">
            </div>
        </div>
    </form>
</body>
    
</html>     